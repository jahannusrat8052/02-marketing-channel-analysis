-- Channel revenue: a segmentation exercise, NOT causal attribution or verified ROAS.
SELECT Channel, COUNT(*) AS completed_orders,
 ROUND(SUM(Qty*UnitPriceBDT*(1-DiscountRate)),2) AS revenue_bdt
FROM orders WHERE Status='Completed' GROUP BY Channel ORDER BY revenue_bdt DESC;
-- Spend dataset is at Month+Channel grain: aggregate first and join at the SAME grain;
-- do not join spend directly to raw orders (duplicates ad spend).
