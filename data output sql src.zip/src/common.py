from pathlib import Path
import csv
from collections import defaultdict, Counter
from decimal import Decimal
ROOT=Path(__file__).resolve().parents[1]
D=lambda n: Decimal(str(n))
def rows(name):
    with (ROOT/'data'/name).open(newline='',encoding='utf-8-sig') as fh:
        return list(csv.DictReader(fh))
def csvout(name, headers, data):
    dest=ROOT/'outputs'/name
    with dest.open('w',newline='',encoding='utf-8') as fh:
        w=csv.writer(fh);w.writerow(headers);w.writerows(data)
def completed_orders():
    return [r for r in rows('orders_clean.csv') if r['Status']=='Completed']
def revenue(r): return D(r['Qty'])*D(r['UnitPriceBDT'])*(1-D(r['DiscountRate']))
def costs(r, products): return D(r['Qty'])*D(products[r['ProductID']]['UnitCostBDT'])
def product_map():return {r['ProductID']:r for r in rows('products.csv')}
