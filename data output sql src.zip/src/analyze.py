from common import *
import matplotlib.pyplot as plt
from collections import defaultdict
import json
bychannel=defaultdict(lambda:[D(0),0]); spend=defaultdict(lambda:D(0))
for r in completed_orders():
    a=bychannel[r['Channel']];a[0]+=revenue(r);a[1]+=1
for r in rows('ad_spend.csv'): spend[r['Channel']]+=D(r['AdSpendBDT'])
out=[]
for channel in sorted(set(bychannel)|set(spend)):
    rev,count=bychannel[channel];s=spend[channel]
    out.append((channel,round(rev,2),round(s,2),count,round(rev/s,3) if s else ''))
assert sum(float(r[2]) for r in out)==138500
csvout('channel_summary.csv',['Channel','RevenueBDT','SpendBDT','CompletedOrders','UnattributedRevenueToSpendRatio'],out)
plt.figure(figsize=(9,4.8));chs=[r[0] for r in out];x=list(range(len(chs)))
plt.bar([i-.18 for i in x],[float(r[1]) for r in out],width=.36,label='Revenue (not attributed)')
plt.bar([i+.18 for i in x],[float(r[2]) for r in out],width=.36,label='Channel spend')
plt.xticks(x,chs,rotation=15);plt.ylabel('BDT');plt.legend();plt.title('Channel Revenue vs Spend (synthetic; NOT ROAS)');plt.tight_layout();plt.savefig(ROOT/'outputs'/'channel_performance.png',dpi=150);plt.close()
print('Created outputs/channel_summary.csv and chart. Total ad-spend BDT 138,500.')
